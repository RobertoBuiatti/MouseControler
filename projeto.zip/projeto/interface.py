
import tkinter as tk
from ttkbootstrap import Style
from ttkbootstrap.widgets import Entry, Combobox, Button, Label, OptionMenu
from detectorFace import (
    start_detection as start_face_detection,
    stop_detection as stop_face_detection,
)
from detectorNose import (
    start_detection as start_nose_detection,
    stop_detection as stop_nose_detection,
)
from detectorEyes import (
    start_detection as start_eyes_detection,
    stop_detection as stop_eyes_detection,
)
import cv2
from PIL import Image, ImageTk
import os
from typing import List, Optional
from dataclasses import dataclass

class DetectorApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Detector Facial")
        self.style = Style(theme="cosmo")
        self.root.configure(bg="black")
        self.camera_config = CameraConfig()
        self.current_detection_mode = "Rosto"
        self.current_theme = "dark"
        self.load_icons()
        self.setup_variables()
        self.create_widgets()
        self.root.mainloop()

    def load_icons(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon')
        moon_icon_image = Image.open(os.path.join(icon_path, 'night.png')).resize((32, 32), Image.Resampling.LANCZOS)
        self.moon_icon = ImageTk.PhotoImage(moon_icon_image)
        sun_icon_image = Image.open(os.path.join(icon_path, 'sun.png')).resize((32, 32), Image.Resampling.LANCZOS)
        self.sun_icon = ImageTk.PhotoImage(sun_icon_image)

    def setup_variables(self):
        self.selected_camera = tk.StringVar()
        self.selected_detection_mode = tk.StringVar()
        self.selected_delay = tk.StringVar()
        self.detection_modes = ["Nariz", "Olhos", "Rosto"]
        self.available_cameras = self.get_available_cameras()
        if self.available_cameras:
            self.selected_camera.set(self.available_cameras[0])
        else:
            self.selected_camera.set("Nenhuma webcam encontrada")

    def get_available_cameras(self):
        index = 0
        arr = []
        while True:
            cap = cv2.VideoCapture(index)
            if not cap.read()[0]:
                break
            else:
                arr.append(str(index))
            cap.release()
            index += 1
        return arr

    def create_widgets(self):
        icon_label = tk.Label(self.root, image=self.moon_icon, bg="black")
        icon_label.grid(row=0, column=0, padx=10, pady=10, sticky="nw")
        icon_label.bind("<Button-1>", lambda e: self.toggle_theme())

        camera_label = Label(
            self.root, text="Selecione a Webcam:", background="black", foreground="white"
        )
        camera_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")

        camera_menu = OptionMenu(self.root, self.selected_camera, *self.available_cameras, style="info")
        camera_menu.grid(row=1, column=1, padx=10, pady=10, sticky="e")

        link_label = Label(
            self.root, text="Ou insira o link da câmera:", background="black", foreground="white"
        )
        link_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        link_entry = Entry(self.root, style="info")
        link_entry.grid(row=2, column=1, padx=10, pady=10, sticky="e")

        detection_mode_label = Label(
            self.root,
            text="Selecione o modo de detecção:",
            background="black",
            foreground="white",
        )
        detection_mode_label.grid(row=3, column=0, padx=10, pady=10, sticky="w")

        detection_mode_menu = Combobox(
            self.root,
            textvariable=self.selected_detection_mode,
            values=self.detection_modes,
            state="readonly",
            style="info",
        )
        detection_mode_menu.grid(row=3, column=1, padx=10, pady=10, sticky="e")

        delay_label = Label(
            self.root,
            text="Digite os frames de parada (0 sem parada):",
            background="black",
            foreground="white",
        )
        delay_label.grid(row=4, column=0, padx=10, pady=10, sticky="w")

        vcmd = self.root.register(self.validate_delay_input)
        delay_entry = Entry(
            self.root,
            textvariable=self.selected_delay,
            validate="key",
            validatecommand=(vcmd, "%P"),
            style="info",
        )
        delay_entry.grid(row=4, column=1, padx=10, pady=10, sticky="e")

        confirm_button = Button(self.root, text="Confirmar", command=self.confirm_link, style="info")
        confirm_button.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

        rotate_button = Button(self.root, text="Rotacionar", command=self.rotate_image, style="info")
        rotate_button.grid(row=6, column=0, columnspan=2, padx=10, pady=10)

        start_button = Button(self.root, text="Iniciar", command=self.start_detection_wrapper, style="info")
        start_button.grid(row=7, column=0, padx=10, pady=10)

        stop_button = Button(self.root, text="Parar", command=self.stop_detection_wrapper, style="info")
        stop_button.grid(row=7, column=1, padx=10, pady=10)

    def confirm_link(self):
        if link_entry.get():
            self.camera_config.source = link_entry.get()
        else:
            self.camera_config.source = int(self.selected_camera.get())
        start_button.config(state=tk.NORMAL if self.camera_config.source else tk.DISABLED)

    def start_detection_wrapper(self):
        self.camera_config.delay = float(self.selected_delay.get())
        self.current_detection_mode = self.selected_detection_mode.get()
        if self.current_detection_mode == "Nariz":
            start_nose_detection(self.camera_config.source, self.camera_config.delay, self.camera_config.rotation)
        elif self.current_detection_mode == "Olhos":
            start_eyes_detection(self.camera_config.source, self.camera_config.delay, self.camera_config.rotation)
        elif self.current_detection_mode == "Rosto":
            start_face_detection(self.camera_config.source, self.camera_config.delay, self.camera_config.rotation)
        else:
            start_face_detection(self.camera_config.source, self.camera_config.delay, self.camera_config.rotation)

    def stop_detection_wrapper(self):
        if self.current_detection_mode == "Nariz":
            stop_nose_detection()
        elif self.current_detection_mode == "Olhos":
            stop_eyes_detection()
        elif self.current_detection_mode == "Rosto":
            stop_face_detection()

    def validate_delay_input(self, P):
        if P.isdigit() or (P == "" or P == "." or (P.startswith("-") and P[1:].isdigit())):
            return True
        else:
            return False

    def toggle_theme(self):
        if self.current_theme == "dark":
            self.style.theme_use("flatly")
            icon_label.config(image=self.sun_icon)
            self.current_theme = "light"
            self.root.configure(bg="white")
        else:
            self.style.theme_use("cosmo")
            icon_label.config(image=self.moon_icon)
            self.current_theme = "dark"
            self.root.configure(bg="black")
        self.update_widget_colors()

    def update_widget_colors(self):
        fg_color = "white" if self.current_theme == "dark" else "black"
        bg_color = "black" if self.current_theme == "dark" else "white"
        camera_label.config(foreground=fg_color, background=bg_color)
        link_label.config(foreground=fg_color, background=bg_color)
        detection_mode_label.config(foreground=fg_color, background=bg_color)
        delay_label.config(foreground=fg_color, background=bg_color)
        self.update_icon_background()

    def update_icon_background(self):
        if self.current_theme == "dark":
            icon_label.config(bg="black")
        else:
            icon_label.config(bg="white")

    def rotate_image(self):
        if self.camera_config.rotation == 0:
            self.camera_config.rotation = 90
        elif self.camera_config.rotation == 90:
            self.camera_config.rotation = 180
        elif self.camera_config.rotation == 180:
            self.camera_config.rotation = 270
        elif self.camera_config.rotation == 270:
            self.camera_config.rotation = 0
        else:
            self.camera_config.rotation = 0  # Valor padrão caso um valor inválido seja passado

@dataclass
class CameraConfig:
    source: Optional[str | int] = None
    delay: float = 1.0
    rotation: int = 0

if __name__ == "__main__":
    app = DetectorApp()
app.root.mainloop()